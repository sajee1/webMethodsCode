package Utilities;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-07-15 15:33:47 EDT
// -----( ON-HOST: appeaiq4.tsg.ge.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.lang.ns.*;
import java.util.ArrayList;
import java.util.List;
import com.wm.lang.ns.NSField;
import java.lang.String;
import java.lang.Exception;
import COM.activesw.api.client.*;
import COM.activesw.api.client.enums.KeystoreType;
import COM.activesw.api.client.enums.TruststoreType;
import java.util.TreeSet;
import java.util.Arrays;
import java.util.Iterator;
import com.wm.util.security.WmSecureString;
import com.wm.app.b2b.server.OutboundPasswordManager;
import com.wm.app.b2b.server.User;
// --- <<IS-END-IMPORTS>> ---

public final class Utils

{
	// ---( internal utility methods )---

	final static Utils _instance = new Utils();

	static Utils _newInstance() { return new Utils(); }

	static Utils _cast(Object o) { return (Utils)o; }

	// ---( server methods )---




	public static final void checkObjectpresenceInInputSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkObjectpresenceInInputSignature)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required fieldName
		IDataCursor pipelineInputCursor = pipeline.getCursor();  
		String serviceName = IDataUtil.getString(pipelineInputCursor,"serviceName");  
		pipelineInputCursor.destroy();  
		String    FieldName ="-1";
		try{
		NSNode nsNode = Namespace.current().getNode(serviceName);  
		if (nsNode instanceof NSService){  
		       NSService serviceNode = (NSService)nsNode;  
		       NSSignature serviceSignature = serviceNode.getSignature();  
		       if (serviceSignature != null){  
		           NSRecord serviceInput = serviceSignature.getInput();  
		           NSRecord serviceOutput = serviceSignature.getOutput();  
			   NSField[] fields = serviceInput.getFields();  
				 for (final NSField field : fields) { 
				String tempName = field.getName();  
		      	        final Integer   FieldType  = Integer.valueOf(field.getType());  
				if(FieldType==3)
		 		FieldName=tempName;}
		          
			}
		    }  
		}
		catch(Exception e){} 
		 IDataCursor pipelineOutputCursor = pipeline.getCursor();  
			   IDataUtil.put(pipelineOutputCursor, "fieldName", FieldName); 	
		           pipelineOutputCursor.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void getBrokerList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBrokerList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required brokerServerHost
		// [i] field:0:required keyStore
		// [i] field:0:required password
		// [i] field:0:required trustStore
		// [o] field:0:required Stats
		// [o] field:1:required BrokerList
		// [o] field:1:required clientIDs
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	brokerServerHost = IDataUtil.getString( pipelineCursor, "brokerServerHost" );
			String	keyStore = IDataUtil.getString( pipelineCursor, "keyStore" );
			String	password = IDataUtil.getString( pipelineCursor, "password" );
			String	trustStore = IDataUtil.getString( pipelineCursor, "trustStore" );
		pipelineCursor.destroy();
		
		// getting BrokerDescriptor 
			BrokerConnectionDescriptor desc = new BrokerConnectionDescriptor();
			BrokerServerClient brokerServerClient = null;
			String Status="Beginning";
			String[] BrokerList =null; 
			String[] clientIDs = null;	
			BrokerAdminClient ac = null;
			if (trustStore != null && keyStore != null && password !=  null){
			try {
			desc.setSSLCertificate(null, trustStore, KeystoreType.PKCS12, TruststoreType.JKS, password);
			brokerServerClient = new BrokerServerClient(brokerServerHost, desc);
			Status=brokerServerClient.getVersion();
			BrokerInfo[] brokerinfos = brokerServerClient.getBrokers();
			BrokerList = new String[brokerinfos.length];
			for (int i = 0; i < brokerinfos.length ; ++i) {
			BrokerList[i]=brokerinfos[i].broker_name;
			}
			ac = new BrokerAdminClient(brokerServerHost, brokerinfos[0].broker_name, null, "admin", "brokerstattestclient", desc);
			clientIDs =  ac.getClientIds();
			} catch (Exception e) {Status=e.getMessage();}
		
		
		// pipeline
		
		IDataUtil.put( pipelineCursor, "Stats", Status );
		IDataUtil.put( pipelineCursor, "BrokerList", BrokerList);
		IDataUtil.put( pipelineCursor, "clientIDs", clientIDs);
		pipelineCursor.destroy();
		
		
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getPassword (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPassword)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required alias
		// [o] field:0:required password
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	alias = IDataUtil.getString( pipelineCursor, "alias" );
		
		// pipeline
		WmSecureString password=null;
		User admin=new User();
		try{
		 	//password = OutboundPasswordManager.retrievePassword((new StringBuilder()).append("user.password.").append(alias).toString());
			boolean isadmin=admin.isAdministrator();
		
		}catch(Exception t){
			t.printStackTrace();
		}
		
		IDataUtil.put( pipelineCursor, "password", password.toString());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeDuplicates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeDuplicates)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required InputList
		// [o] field:1:required OutputList
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	InputList = IDataUtil.getStringArray( pipelineCursor, "InputList" );
		
		String[] OutputList = null;
		List<String> tmpList = Arrays.asList(InputList);
		TreeSet<String> unique = new TreeSet<String>(tmpList);
		Iterator it = unique.iterator();
		int i=0;
		OutputList=new String[unique.size()];
		while(it.hasNext()) {
		 OutputList[i]=it.next().toString();
		  i++;
		}
		
		// pipeline
		
		IDataUtil.put( pipelineCursor, "OutputList", OutputList );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

